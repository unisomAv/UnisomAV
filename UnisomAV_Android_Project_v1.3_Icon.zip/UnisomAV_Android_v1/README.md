# Unisom.AV 1.2

MVP Android/WebView da plataforma Unisom.AV.

## Incluído nesta versão
- Pesquisa e filtros locais
- Categorias navegáveis
- Perfis de artistas
- Contratação e pedidos de Booking guardados no dispositivo
- Oportunidades e candidaturas locais
- Fluxo “Preciso de um artista” com correspondências locais
- Mensagens locais entre utilizador e artistas
- Perfil do utilizador com edição local
- Histórico local de Bookings
- Solicitação do Unisom.AV Card

## Limitação do MVP
Esta versão não possui backend, autenticação, base de dados online ou pagamentos reais. Esses componentes serão ligados numa fase posterior.

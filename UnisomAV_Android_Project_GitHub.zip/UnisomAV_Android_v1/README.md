# Unisom.AV Android v1.0
MVP Android nativo com WebView e interface mobile.

## Gerar APK
Abra esta pasta no Android Studio, aguarde o Gradle Sync e use:
Build > Build APK(s)

APK de debug: app/build/outputs/apk/debug/app-debug.apk

## Próxima fase
Backend, autenticação, base de dados, chat, notificações, bookings reais,
contratos, pagamentos via parceiro autorizado, painel administrativo e publicação na Play Store.

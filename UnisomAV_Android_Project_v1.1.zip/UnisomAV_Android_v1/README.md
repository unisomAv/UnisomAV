# Unisom.AV 1.1

MVP Android da Unisom.AV, plataforma para conectar talentos criativos, contratantes e oportunidades.

## Nesta versão
- Pesquisa funcional por artista, categoria, serviço e oportunidade.
- Categorias funcionais.
- Perfis de artistas com serviços, preços e avaliações demonstrativas.
- Fluxo de Contratar/Booking com formulário.
- Oportunidades navegáveis.
- Navegação inferior funcional para Início, Pesquisa, Mensagens e Perfil.
- Compatível com a estrutura WebView existente do projeto.

## Nota
Esta versão é um MVP local: os dados são demonstrativos e ainda não são persistidos num servidor. Autenticação, base de dados, notificações, pagamentos e matching real ficam para a próxima fase.
